### Índice

* [Python](#python)


### Python

* [Guia de Instalação do Kivy](https://pythonacademy.com.br/sliders/como-instalar-o-kivy)
