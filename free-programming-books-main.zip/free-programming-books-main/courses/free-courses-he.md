### Index

* [C++](#cpp)
* [Python](#python)
* [R](#r)


### <a id="cpp"></a>C++

* [מבוא לתכנות בשפת C++](https://campus.gov.il/course/course-v1-basmach-pc264/) (קמפוסIL ובסמ״ח)


### Python

* [Self.py – הדרך שלך ללמוד פייתון](https://campus.gov.il/course/course-v1-cs-gov_cs_selfpy101/) (קמפוסIL והמרכז לחינוך סייבר)
* [Next.py – הצעד הבא שלך בפייתון](https://campus.gov.il/course/course-v1-cs-gov-cs-nextpy102/) (קמפוסIL והמרכז לחינוך סייבר)
* [network.py לתכנת במרחב הרשת](https://campus.gov.il/course/cs-gov-cs-networkpy103-2020-1/) (קמפוסIL והמרכז לחינוך סייבר)


### R

* [מבוא לתכנות ועיבוד נתונים בשפת R](https://campus.gov.il/course/telhai-acd-rfp4-telhai-r/) (קמפוסIL ומכללת תל־חי)
